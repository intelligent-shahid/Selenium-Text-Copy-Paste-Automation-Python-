from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver import ActionChains

# Chrome driver path
srv_obj = Service(r"C:\webdrivers\chromedriver.exe")
driver = webdriver.Chrome(service=srv_obj)

driver.maximize_window()
driver.get("https://text-compare.com")
driver.implicitly_wait(10)

# Locate input boxes
input1 = driver.find_element(By.XPATH, "//textarea[@id='inputText1']")
input2 = driver.find_element(By.XPATH, "//textarea[@id='inputText2']")

# Type text in first box
input1.send_keys("Welcome to professionalism")

# Actions
act = ActionChains(driver)

# CTRL + A and CTRL + C
act.key_down(Keys.CONTROL).send_keys("a").key_up(Keys.CONTROL).perform()
act.key_down(Keys.CONTROL).send_keys("c").key_up(Keys.CONTROL).perform()
driver.sleep(2)
# TAB to move to 2nd box
act.send_keys(Keys.TAB).perform()
driver.sleep(3)
# CTRL + V
act.key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()

if input1.get_attribute('value') == input2.get_attribute('value'):
    print("Both texts are same")
else:
    print("Texts are different")
